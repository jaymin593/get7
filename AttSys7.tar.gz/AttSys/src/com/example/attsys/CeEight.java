package com.example.attsys;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class CeEight extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ce8_list_layout);
        
        ArrayList<CeEightGetSet> searchResults = GetSearchResults();
        
        final ListView lv1 = (ListView) findViewById(R.id.ListView01);
        lv1.setAdapter(new CeEightBaseAdapter(this, searchResults));
        
        lv1.setOnItemClickListener(new OnItemClickListener() {
        	@Override
        	public void onItemClick(AdapterView<?> a, View v, int position, long id) { 
        		Object o = lv1.getItemAtPosition(position);
            	CeEightGetSet fullObject = (CeEightGetSet)o;
        		Toast.makeText(CeEight.this, "You have chosen: " + " " + fullObject.getName(), Toast.LENGTH_LONG).show();
        	}  
        });
    }
    
    private ArrayList<CeEightGetSet> GetSearchResults(){
    	ArrayList<CeEightGetSet> results = new ArrayList<CeEightGetSet>();
    	
    	CeEightGetSet sr1 = new CeEightGetSet();
    	sr1.setName("100560107001");
    	sr1.setCityState("Patel Dusyant");
    	sr1.setPhone("+919409629707");
    	results.add(sr1);
    	
    	sr1 = new CeEightGetSet();
    	sr1.setName("100560107002");
    	sr1.setCityState("Kyada Nikunj");
    	sr1.setPhone("+919624725181");
    	results.add(sr1);
    	
    	sr1 = new CeEightGetSet();
    	sr1.setName("100560107003");
    	sr1.setCityState("Patel Bhavesh");
    	sr1.setPhone("+919737426316");
    	results.add(sr1);
    	
    	sr1 = new CeEightGetSet();
    	sr1.setName("100560107004");
    	sr1.setCityState("Patel Dhaval");
    	sr1.setPhone("+919408723986");
    	results.add(sr1);
    	
    	sr1 = new CeEightGetSet();
    	sr1.setName("100560107005");
    	sr1.setCityState("Patel Hiren");
    	sr1.setPhone("+919409190450");
    	results.add(sr1);
    	
    	sr1 = new CeEightGetSet();
    	sr1.setName("100560107006");
    	sr1.setCityState("Hirapara Varshaguari");
    	sr1.setPhone("+918128934145");
    	results.add(sr1);
    	
    	sr1 = new CeEightGetSet();
    	sr1.setName("100560107007");
    	sr1.setCityState("Kachhadiya Pratik");
    	sr1.setPhone("+919714861487");
    	results.add(sr1);
    	
    	sr1 = new CeEightGetSet();
    	sr1.setName("100560107011");
    	sr1.setCityState("Patel Rahul");
    	sr1.setPhone("+919409338735");
    	results.add(sr1);
    	
    	return results;
   
    }
    
    public void backmethod(View v)
    {
    	startActivity(new Intent(this, AttForm.class));
    }
    
    @SuppressWarnings("deprecation")
	public void infomethod(View v){
    	AlertDialog alertDialog = new AlertDialog.Builder(this).create();
    	alertDialog.setTitle("Sorry");
    	alertDialog.setMessage("Temporary Data Connection Stop");
    	alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
    	   public void onClick(DialogInterface dialog, int which) {
    	      // TODO Add your code for the button here.
    	   }
    	});
    	// Set the Icon for the Dialog
    	alertDialog.setIcon(R.drawable.udimage);
    	alertDialog.show();
    }
    
    @SuppressWarnings("deprecation")
	public void submitsuccess(View v){
    	AlertDialog alertDialog1 = new AlertDialog.Builder(this).create();
    	alertDialog1.setTitle("Report");
    	alertDialog1.setMessage("Attendance Submited successfuly");
    	alertDialog1.setButton("OK", new DialogInterface.OnClickListener() {
     	   public void onClick(DialogInterface dialog, int which) {
     	      // TODO Add your code for the button here.
     	   }
     	});
    	alertDialog1.setIcon(R.drawable.success);
    	alertDialog1.show();
    	
    }
}