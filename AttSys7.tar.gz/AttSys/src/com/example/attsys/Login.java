package com.example.attsys;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;



public class Login<TestMain> extends Activity {
    private static final int DIALOG_REALLY_EXIT_ID = 0;



	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
         }

    
    public void loginmethod(View v)
    {
    	startActivity(new Intent(this, HomeActivity.class));
    }
    
    public void backmethod(View v)
    {
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Abe Oyeeee");
        builder.setMessage("Bahar Jayega ka Ghochu???");
        builder.setPositiveButton("Jaunga", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //super.onBackPressed();
            	finish();
                System.exit(0);
            }
        });
        builder.setNegativeButton("Nahiii", null);
        builder.show();  
    }
     
        // manages key presses not handled in other Views from this Activity
        @SuppressWarnings("deprecation")
		@Override
        public boolean onKeyDown(int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK)
                showDialog(DIALOG_REALLY_EXIT_ID);
     
            return true;
            // use this instead if you want to preserve onKeyDown() behavior
            // return super.onKeyDown(keyCode, event);
        }
    
    
    
    @SuppressWarnings("deprecation")
	public void infomethod(View v){
    	AlertDialog alertDialog = new AlertDialog.Builder(this).create();
    	alertDialog.setTitle("Sorry");
    	alertDialog.setMessage("Temporary Data Connection Stop");
    	alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
    	   public void onClick(DialogInterface dialog, int which) {
    	      // TODO Add your code for the button here.
    	   }
    	});
    	// Set the Icon for the Dialog
    	alertDialog.setIcon(R.drawable.udimage);
    	alertDialog.show();
    }
    protected Dialog onCreateDialog(int id) {
        final Dialog dialog;
        switch(id) {
        case DIALOG_REALLY_EXIT_ID:
            dialog = new AlertDialog.Builder(this).setMessage(
                                "Are you sure you want to exit?")
            .setCancelable(false)
            .setPositiveButton("Yes",
                    new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Login.this.finish();
                }
            })
            .setNegativeButton("No",
                    new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            }).create();
            break;
        default:
            dialog = null;
        }
        return dialog;
    }
 
}